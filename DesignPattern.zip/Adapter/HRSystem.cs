namespace Adapter
{
    public class HRSystem
    {
        public string[] Employees = {
            "John, Accounting, 3000",
            "Maria, IT, 4500",
            "Peter, HR, 2800"
        };
    }
}